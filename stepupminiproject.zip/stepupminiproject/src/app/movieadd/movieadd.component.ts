import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { UserServiceService } from '../user-service.service';

@Component({
  selector: 'app-movieadd',
  templateUrl: './movieadd.component.html',
  styleUrls: ['./movieadd.component.css']
})
export class MovieaddComponent implements OnInit {
  moviedata:any=[]
   
  constructor(private service:UserServiceService) { }
selected:any=false
  ngOnInit(): void {
    this.moviedata=this.service.getMovies()
  }



}

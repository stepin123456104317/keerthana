import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CartComponent } from './cart/cart.component';
import { ContactusComponent } from './contactus/contactus.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';
import { MovieaddComponent } from './movieadd/movieadd.component';
import { MoviedetailsComponent } from './moviedetails/moviedetails.component';
import { MovieinfoComponent } from './movieinfo/movieinfo.component';

const routes: Routes = [
  {path:'login',component:LoginComponent},
  {path:'home',component:HomeComponent},
  {path:'contact',component:ContactusComponent},
  {path:'movieinfo',component:MovieinfoComponent},
  {path:'movieadd',component:MovieaddComponent},
  {path:'logout',component:LogoutComponent},
  {path:'moviedetails',component:MoviedetailsComponent},
  {path:'cart',component:CartComponent},
  {path:'',redirectTo:'login',pathMatch:'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

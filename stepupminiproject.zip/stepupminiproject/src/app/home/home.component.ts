import { Component, OnInit } from '@angular/core';
import * as am4core from "@amcharts/amcharts4/core";
import * as am4charts from "@amcharts/amcharts4/charts";


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
    let chart = am4core.create("chartdiv", am4charts.XYChart);
    chart.data = [{
      "movie": "Roohi",
      "Rating": 2
    }, {
      "movie": "Mumbai Saga",
      "Rating": 4
    }, {
      "movie": "Krack",
      "Rating": 9
    }, {
      "movie": "Uppena",
      "Rating": 8
    },{
      "movie": "Singam 3",
      "Rating": 9
    },
    {
      "movie": "BahuBali",
      "Rating": 10
    }];

    let categoryAxis = chart.xAxes.push(new am4charts.CategoryAxis());
categoryAxis.dataFields.category = "movie";
categoryAxis.renderer.grid.template.location = 0;
categoryAxis.renderer.minGridDistance = 30;

// categoryAxis.renderer.labels.template.adapter.add("dy", function(dy, target) {
//   if (target.dataItem && target.dataItem.index) {
//     return dy +8 25;
//   }
//   return dy;
// });
let valueAxis = chart.yAxes.push(new am4charts.ValueAxis());

// Create series
let series = chart.series.push(new am4charts.ColumnSeries());
series.dataFields.valueY = "Rating";
series.dataFields.categoryX = "movie";
series.name = "Rating";
series.columns.template.tooltipText = "{categoryX}: [bold]{valueY}[/]";
series.columns.template.fillOpacity = .8;

let columnTemplate = series.columns.template;
columnTemplate.strokeWidth = 2;
columnTemplate.strokeOpacity = 1;
  }


}

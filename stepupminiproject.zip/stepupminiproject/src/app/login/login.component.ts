import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserServiceService } from '../user-service.service';
import Swal from 'sweetalert2'
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private service:UserServiceService,private router: Router) { }
  validuser:any;
  loginForm:any
  // getErrorMessage() {
  //   if (this.email.hasError('required')) {
  //     return 'You must enter a value';
  //   }

  //   return this.email.hasError('email') ? 'Not a valid email' : '';
  // }

  ngOnInit(): void {
    this.createForm();
  }
  createForm()
  {
    this.loginForm=new FormGroup(
      {
      username: new FormControl('', [Validators.required, Validators.email]),
      password:new FormControl('',[Validators.required])
    }

    )
  }
  onLogin(){
    this.validuser=this.service.validUser(this.loginForm.get('username').value,this.loginForm.get('password').value)
     if(this.validuser)
     {
     this.router.navigateByUrl('/home');
     }
     else{
Swal.fire('Invalid Username/Password')
     }
  }    

}

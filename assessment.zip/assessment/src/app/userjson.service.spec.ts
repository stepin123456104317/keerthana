import { TestBed } from '@angular/core/testing';

import { UserjsonService } from './userjson.service';

describe('UserjsonService', () => {
  let service: UserjsonService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(UserjsonService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

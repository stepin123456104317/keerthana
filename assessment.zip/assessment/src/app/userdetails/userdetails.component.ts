import { Component, Input, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';
import {UserjsonService} from '../userjson.service'

@Component({
  selector: 'app-userdetails',
  templateUrl: './userdetails.component.html',
  styleUrls: ['./userdetails.component.css']
})
export class UserdetailsComponent implements OnInit {
  products:any;
  first:any;
  @Input() username:any;
  constructor(private userjson:UserjsonService,private route:ActivatedRoute) { }
 
  ngOnInit(): void {
    this.username=this.route.snapshot.params.username
    console.log(this.username)
    this.userjson.sendGetRequest().subscribe((data: any)=>{
      console.log(data);
      this.products = data;
     console.log(this.username)
     for(let i in this.products){
       if(this.products[i].login==this.username){
         this.first=JSON.stringify(this.products[i]);
       }
     }
    }) 
  }

}

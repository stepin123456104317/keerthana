import { Component, OnInit, Output } from '@angular/core';
import {UserjsonService} from '../userjson.service'
@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  products:any;
  @Output ()username:any;
  constructor(private userjson:UserjsonService) { }

  ngOnInit() {
    this.userjson.sendGetRequest().subscribe((data: any)=>{
      console.log(data);
      this.products = data;
      this.username=this.products[1].login;
    }) 
  }
check(){

}
}
